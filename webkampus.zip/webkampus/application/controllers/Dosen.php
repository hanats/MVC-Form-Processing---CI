<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dosen extends CI_Controller {
    public function index()
    {
    $this->load->model('dosen_model','dsn1');
    $this->dsn1->nidn='01001';
    $this->dsn1->nama='Hana Yasmin';
    $this->dsn1->gender='P';
    $this->dsn1->matkul='Pemograman Web';

    $this->load->model('dosen_model','dsn2');
    $this->dsn2->nidn='01002';
    $this->dsn2->nama='Isyaka Aditya Demas';
    $this->dsn2->gender='L';
    $this->dsn2->matkul='Statistika';

	$this->load->model('dosen_model','dsn3');
    $this->dsn3->nidn='01003';
    $this->dsn3->nama='Siti Amdah';
    $this->dsn3->gender='P';
    $this->dsn3->matkul='UI/UX';

    $list_dsn = [$this->dsn1, $this->dsn2, $this->dsn3];
    $data['list_dsn']=$list_dsn;
    $this->load->view('layout/header');
    $this->load->view('layout/sidebar');
    $this->load->view('dosen/index',$data);
    $this->load->view('layout/footer');
    }
}

?>